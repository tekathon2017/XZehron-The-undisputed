/**
 * 
 */
package caf.war.Notifications2Citizens.publishnotifications;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues;

import com.webmethods.caf.faces.annotations.ExpireWithPageFlow;
import com.webmethods.caf.faces.annotations.DTManagedBean;
import com.webmethods.caf.faces.annotations.BeanType;

/**
 * @author nmanchin
 *
 */

@ManagedBean(name = "PublishNotificationsDefaultviewView")
@SessionScoped
@ExpireWithPageFlow
@DTManagedBean(displayName = "PublishNotifications/default", beanType = BeanType.PAGE)
public class PublishNotificationsDefaultviewView  extends   com.webmethods.caf.faces.bean.BasePageBean {

	/**
	 * Determines if a de-serialized file is compatible with this class.
	 *
	 * Maintainers must change this value if and only if the new version
	 * of this class is not compatible with old versions. See Sun docs
	 * for <a href=http://java.sun.com/j2se/1.5.0/docs/guide/serialization/spec/version.html> 
	 * details. </a>
	 */
	private static final long serialVersionUID = 1L;
	private static final String[][] INITIALIZE_PROPERTY_BINDINGS = new String[][] {
	};
	private transient caf.war.Notifications2Citizens.publishnotifications.PublishNotifications publishNotifications = null;
	private transient caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues getLookupValues = null;
	/**
	 * Initialize page
	 */
	public String initialize() {
		try {
		    resolveDataBinding(INITIALIZE_PROPERTY_BINDINGS, null, "initialize", true, false);
		    setLogInUser(getFacesContext().getExternalContext().getUserPrincipal().getName());
		} catch (Exception e) {
			error(e);
			log(e);
		}
		return null;	
	}

	String logInUser=null;
	public String getLogInUser() {
		return logInUser;
	}

	public void setLogInUser(String logInUser) {
		this.logInUser = logInUser;
	}

	public caf.war.Notifications2Citizens.publishnotifications.PublishNotifications getPublishNotifications()  {
		if (publishNotifications == null) {
		    publishNotifications = (caf.war.Notifications2Citizens.publishnotifications.PublishNotifications)resolveExpression("#{PublishNotifications}");
		}
		return publishNotifications;
	}

	/**
	 * Action Event Handler for the control with id='populateCircle'
	 */
	public String populateCircle_action() {
		  // TODO: perform your action logic here
		
		//getLookupValues.getParameters().getGetLookupValues().getGetLookupValues().setId("CIRCLE");
		//getLookupValues.getParameters().getGetLookupValues().getGetLookupValues().setKey(getPostcode());
		//getLookupValues.refresh();
		//setCircleList(getLookupValues.getResult().getGetLookupValuesResponse().getValues());
	    return null;
	}

	public caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues getGetLookupValues()  {
		if (getLookupValues == null) {
		    getLookupValues = (caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues)resolveExpression("#{GetLookupValues}");
		}
	
	    resolveDataBinding(GETLOOKUPVALUES_PROPERTY_BINDINGS, getLookupValues, "getLookupValues", false, false);
		return getLookupValues;
	}

	public void setGetLookupValues(caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues getLookupValues)  {
		this.getLookupValues = getLookupValues;
	}
	
	String [] circleList =null;
	String postcode =null;
	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String[] getCircleList() {
		return circleList;
	}

	public void setCircleList(String[] circleList) {
		this.circleList = circleList;
	}
	
	String circleId="CIRCLE";
	private static final String[][] GETLOOKUPVALUES_PROPERTY_BINDINGS = new String[][] {
		{"#{getLookupValues.authCredentials.authenticationMethod}", "1"},
		{"#{getLookupValues.authCredentials.requiresAuth}", "true"},
		{"#{getLookupValues.endpointAddress}", "http://HSCSRV164.allegisgroup.com:5599/ws/TekathonxZeron.ws.lookupValues"},
		{"#{getLookupValues.parameters.getLookupValues.getLookupValues.key}", "#{PublishNotificationsDefaultviewView.postcode}"},
		{"#{getLookupValues.parameters.getLookupValues.getLookupValues.id}", "CIRCLE"},
	};
	private transient caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues2 getLookupValues2 = null;
	public String getCircleId() {
		return circleId;
	}

	public void setCircleId(String circleId) {
		this.circleId = circleId;
	}

	public caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues2 getGetLookupValues2()  {
		if (getLookupValues2 == null) {
		    getLookupValues2 = (caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues2)resolveExpression("#{GetLookupValues2}");
		}
	
	    resolveDataBinding(GETLOOKUPVALUES2_PROPERTY_BINDINGS, getLookupValues2, "getLookupValues2", false, false);
		return getLookupValues2;
	}

	public void setGetLookupValues2(caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues2 getLookupValues2)  {
		this.getLookupValues2 = getLookupValues2;
	}
	String selectedCircle=null;
	private static final String[][] GETLOOKUPVALUES2_PROPERTY_BINDINGS = new String[][] {
		{"#{getLookupValues2.authCredentials.authenticationMethod}", "1"},
		{"#{getLookupValues2.authCredentials.requiresAuth}", "true"},
		{"#{getLookupValues2.endpointAddress}", "http://HSCSRV164.allegisgroup.com:5599/ws/TekathonxZeron.ws.lookupValues"},
		{"#{getLookupValues2.parameters.getLookupValues.getLookupValues.id}", "DIVISION"},
		{"#{getLookupValues2.parameters.getLookupValues.getLookupValues.key}", "#{PublishNotificationsDefaultviewView.selectedCircle}"},
	};
	private transient caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues3 getLookupValues3 = null;
	public String getSelectedCircle() {
		return selectedCircle;
	}

	public void setSelectedCircle(String selectedCircle) {
		this.selectedCircle = selectedCircle;
	}

	public caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues3 getGetLookupValues3()  {
		if (getLookupValues3 == null) {
		    getLookupValues3 = (caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues3)resolveExpression("#{GetLookupValues3}");
		}
	
	    resolveDataBinding(GETLOOKUPVALUES3_PROPERTY_BINDINGS, getLookupValues3, "getLookupValues3", false, false);
		return getLookupValues3;
	}

	public void setGetLookupValues3(caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues3 getLookupValues3)  {
		this.getLookupValues3 = getLookupValues3;
	}
	String selectedDiv=null;
	private static final String[][] GETLOOKUPVALUES3_PROPERTY_BINDINGS = new String[][] {
		{"#{getLookupValues3.authCredentials.authenticationMethod}", "1"},
		{"#{getLookupValues3.authCredentials.requiresAuth}", "true"},
		{"#{getLookupValues3.endpointAddress}", "http://HSCSRV164.allegisgroup.com:5599/ws/TekathonxZeron.ws.lookupValues"},
		{"#{getLookupValues3.parameters.getLookupValues.getLookupValues.id}", "LANE"},
		{"#{getLookupValues3.parameters.getLookupValues.getLookupValues.key}", "#{PublishNotificationsDefaultviewView.selectedDiv}"},
	};
	private transient caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerincident.RegisterIncident registerIncident = null;
	private static final String[][] REGISTERINCIDENT_PROPERTY_BINDINGS = new String[][] {
		{"#{registerIncident.authCredentials.authenticationMethod}", "1"},
		{"#{registerIncident.authCredentials.requiresAuth}", "true"},
		{"#{registerIncident.parameters.registerIncident.registerIncident.registerIncidentRequest.incidentDetails.area}", "#{PublishNotificationsDefaultviewView.postcode}"},
		{"#{registerIncident.parameters.registerIncident.registerIncident.registerIncidentRequest.incidentDetails.circle}", "#{PublishNotificationsDefaultviewView.selectedCircle}"},
		{"#{registerIncident.parameters.registerIncident.registerIncident.registerIncidentRequest.incidentDetails.division}", "#{PublishNotificationsDefaultviewView.selectedDiv}"},
		{"#{registerIncident.parameters.registerIncident.registerIncident.registerIncidentRequest.incidentDetails.state}", "Telangana"},
		{"#{registerIncident.parameters.registerIncident.registerIncident.registerIncidentRequest.incidentDetails.city}", "Hyderabad"},
		{"#{registerIncident.endpointAddress}", "http://HSCSRV164.allegisgroup.com:5599/ws/TekathonxZeron.ws.registerIncident"},
		{"#{registerIncident.parameters.registerIncident.registerIncident.registerIncidentRequest.incidentDetails.createdBy}", "#{PublishNotificationsDefaultviewView.logInUser}"},
		{"#{registerIncident.result.registerIncidentResponse.registerIncidentResponse.message}", "#{PublishNotificationsDefaultviewView.registerIncident.result.registerIncidentResponse.registerIncidentResponse.message}"},
	};
	public String getSelectedDiv() {
		return selectedDiv;
	}

	public void setSelectedDiv(String selectedDiv) {
		this.selectedDiv = selectedDiv;
	}

	public caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerincident.RegisterIncident getRegisterIncident()  {
		if (registerIncident == null) {
		    registerIncident = (caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerincident.RegisterIncident)resolveExpression("#{RegisterIncident}");
		}
	
	    resolveDataBinding(REGISTERINCIDENT_PROPERTY_BINDINGS, registerIncident, "registerIncident", false, false);
		return registerIncident;
	}

	public void setRegisterIncident(caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerincident.RegisterIncident registerIncident)  {
		this.registerIncident = registerIncident;
	}
}