package caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerincident;


import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import com.webmethods.caf.faces.annotations.ExpireWithPageFlow;
import com.webmethods.caf.faces.annotations.DTManagedBean;
import com.webmethods.caf.faces.annotations.BeanType;

/**
 * Web Service Client bean generated for 
 * caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerincident.TekathonxZeronWsRegisterIncidentStub.registerIncident.
 */
@ManagedBean(name = "RegisterIncident")
@SessionScoped
@ExpireWithPageFlow
@DTManagedBean(beanType = BeanType.DEFAULT)
public class RegisterIncident extends com.webmethods.caf.faces.data.ws.wss.WSSContentProvider {

	private static final long serialVersionUID = 6857239480439234560L;
	
	/**
	 * Constructor
	 */
	public RegisterIncident() {
		super(caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerincident.TekathonxZeronWsRegisterIncidentStub.class,  // port type proxy class
			"registerIncident", // method to invoke
			new String[] { "registerIncident", } // method parameter names
		);
		
		// init wsclient
		initParams();
		
		
		// parameters bean
		parameters = new Parameters();
			
		// initial result
		result = null;
	}
	
	
	/**
	 * Method parameters bean
	 */
	public class Parameters implements Serializable {

		private static final long serialVersionUID = 6803455695669081088L;
		
		public Parameters() {
		}
	
	  
		private caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerincident.TekathonxZeronWsRegisterIncidentStub.RegisterIncidentE registerIncident  = new  caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerincident.TekathonxZeronWsRegisterIncidentStub.RegisterIncidentE() ;

		public caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerincident.TekathonxZeronWsRegisterIncidentStub.RegisterIncidentE getRegisterIncident() {
			return registerIncident;
		}

		public void setRegisterIncident(caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerincident.TekathonxZeronWsRegisterIncidentStub.RegisterIncidentE registerIncident) {
			this.registerIncident = registerIncident;
		}
		
	}
	
	/**
	 * Return method invocation parameters bean
	 */
	public Parameters getParameters() {
		return (Parameters)parameters;
	}	
	


	
	/**
	 * Return method invocation result bean
	 */
	public caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerincident.TekathonxZeronWsRegisterIncidentStub.RegisterIncidentResponseE getResult() {
		return (caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerincident.TekathonxZeronWsRegisterIncidentStub.RegisterIncidentResponseE)result;
	}
	
	
}