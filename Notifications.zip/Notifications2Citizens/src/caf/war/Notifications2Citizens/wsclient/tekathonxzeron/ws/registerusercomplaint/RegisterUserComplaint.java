package caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerusercomplaint;


import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import com.webmethods.caf.faces.annotations.ExpireWithPageFlow;
import com.webmethods.caf.faces.annotations.DTManagedBean;
import com.webmethods.caf.faces.annotations.BeanType;

/**
 * Web Service Client bean generated for 
 * caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerusercomplaint.TekathonxZeronWsRegisterUserComplaintStub.registerUserComplaint.
 */
@ManagedBean(name = "RegisterUserComplaint")
@SessionScoped
@ExpireWithPageFlow
@DTManagedBean(beanType = BeanType.DEFAULT)
public class RegisterUserComplaint extends com.webmethods.caf.faces.data.ws.wss.WSSContentProvider {

	private static final long serialVersionUID = 5116621979534324736L;
	
	/**
	 * Constructor
	 */
	public RegisterUserComplaint() {
		super(caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerusercomplaint.TekathonxZeronWsRegisterUserComplaintStub.class,  // port type proxy class
			"registerUserComplaint", // method to invoke
			new String[] { "registerUserComplaint", } // method parameter names
		);
		
		// init wsclient
		initParams();
		
		
		// parameters bean
		parameters = new Parameters();
			
		// initial result
		result = null;
	}
	
	
	/**
	 * Method parameters bean
	 */
	public class Parameters implements Serializable {

		private static final long serialVersionUID = 1205349016213873664L;
		
		public Parameters() {
		}
	
	  
		private caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerusercomplaint.TekathonxZeronWsRegisterUserComplaintStub.RegisterUserComplaintE registerUserComplaint  = new  caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerusercomplaint.TekathonxZeronWsRegisterUserComplaintStub.RegisterUserComplaintE() ;

		public caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerusercomplaint.TekathonxZeronWsRegisterUserComplaintStub.RegisterUserComplaintE getRegisterUserComplaint() {
			return registerUserComplaint;
		}

		public void setRegisterUserComplaint(caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerusercomplaint.TekathonxZeronWsRegisterUserComplaintStub.RegisterUserComplaintE registerUserComplaint) {
			this.registerUserComplaint = registerUserComplaint;
		}
		
	}
	
	/**
	 * Return method invocation parameters bean
	 */
	public Parameters getParameters() {
		return (Parameters)parameters;
	}	
	


	
	/**
	 * Return method invocation result bean
	 */
	public caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerusercomplaint.TekathonxZeronWsRegisterUserComplaintStub.RegisterUserComplaintResponseE getResult() {
		return (caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerusercomplaint.TekathonxZeronWsRegisterUserComplaintStub.RegisterUserComplaintResponseE)result;
	}
	
	
}