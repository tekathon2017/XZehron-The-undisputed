/**
 * 
 */
package caf.war.Notifications2Citizens;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ApplicationScoped;
import com.webmethods.caf.faces.annotations.DTManagedBean;
import com.webmethods.caf.faces.annotations.BeanType;

/**
 * @author nmanchin
 *
 */
@ManagedBean(name = "Notifications2Citizens")
@ApplicationScoped
@DTManagedBean(displayName = "Notifications2Citizens", beanType = BeanType.APPLICATION)
public class Notifications2Citizens extends com.webmethods.caf.faces.bean.BaseApplicationBean 
{
	public Notifications2Citizens()
	{
		super();
		setCategoryName( "CafApplication" );
		setSubCategoryName( "Notifications2Citizens" );
	}
}