/**
 * 
 */
package caf.war.Notifications2Citizens.viewnotifications;

/**
 * @author nmanchin
 *
 */

import javax.portlet.PortletPreferences;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import com.webmethods.caf.faces.annotations.ExpireWithPageFlow;
import com.webmethods.caf.faces.annotations.DTManagedBean;
import com.webmethods.caf.faces.annotations.BeanType;

@ManagedBean(name = "ViewNotifications")
@SessionScoped
@ExpireWithPageFlow
@DTManagedBean(displayName = "ViewNotifications", beanType = BeanType.PORTLET)
public class ViewNotifications  extends   com.webmethods.caf.faces.bean.BaseFacesPreferencesBean {

	public static final String[] PREFERENCES_NAMES = new String[] {};
	private transient caf.war.Notifications2Citizens.Notifications2Citizens notifications2Citizens = null;
	
	/**
	 * Create new preferences bean with list of preference names
	 */
	public ViewNotifications() {
		super(PREFERENCES_NAMES);
	}
	
	/**
	 * Call this method in order to persist
	 * Portlet preferences
	 */
	public void storePreferences() throws Exception {
		updatePreferences();
		PortletPreferences preferences = getPreferences();
		preferences.store();
	}

	public caf.war.Notifications2Citizens.Notifications2Citizens getNotifications2Citizens()  {
		if (notifications2Citizens == null) {
		    notifications2Citizens = (caf.war.Notifications2Citizens.Notifications2Citizens)resolveExpression("#{Notifications2Citizens}");
		}
		return notifications2Citizens;
	}
}