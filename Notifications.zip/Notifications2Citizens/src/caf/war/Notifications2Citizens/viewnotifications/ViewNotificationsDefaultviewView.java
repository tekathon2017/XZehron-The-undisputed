/**
 * 
 */
package caf.war.Notifications2Citizens.viewnotifications;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.getactivenotification.GetActiveNotification;

import com.webmethods.caf.faces.annotations.ExpireWithPageFlow;
import com.webmethods.caf.faces.annotations.DTManagedBean;
import com.webmethods.caf.faces.annotations.BeanType;

/**
 * @author nmanchin
 *
 */

@ManagedBean(name = "ViewNotificationsDefaultviewView")
@SessionScoped
@ExpireWithPageFlow
@DTManagedBean(displayName = "ViewNotifications/default", beanType = BeanType.PAGE)
public class ViewNotificationsDefaultviewView  extends   com.webmethods.caf.faces.bean.BasePageBean {

	/**
	 * Determines if a de-serialized file is compatible with this class.
	 *
	 * Maintainers must change this value if and only if the new version
	 * of this class is not compatible with old versions. See Sun docs
	 * for <a href=http://java.sun.com/j2se/1.5.0/docs/guide/serialization/spec/version.html> 
	 * details. </a>
	 */
	private static final long serialVersionUID = 1L;
	private static final String[][] INITIALIZE_PROPERTY_BINDINGS = new String[][] {
	};
	private transient caf.war.Notifications2Citizens.viewnotifications.ViewNotifications viewNotifications = null;
	/**
	 * Initialize page
	 */
	public String initialize() {
		try {
		    resolveDataBinding(INITIALIZE_PROPERTY_BINDINGS, null, "initialize", true, false);
		    setLogInUser(getFacesContext().getExternalContext().getUserPrincipal().getName());
		} catch (Exception e) {
			error(e);
			log(e);
		}
		return null;	
	}

	public caf.war.Notifications2Citizens.viewnotifications.ViewNotifications getViewNotifications()  {
		if (viewNotifications == null) {
		    viewNotifications = (caf.war.Notifications2Citizens.viewnotifications.ViewNotifications)resolveExpression("#{ViewNotifications}");
		}
		return viewNotifications;
	}

	@Override
	protected void beforeRenderResponse() {
		// TODO Auto-generated method stub
		super.beforeRenderResponse();
		getGetActiveNotification().refresh();
	}
	  String logInUser =null;
	private transient caf.war.Notifications2Citizens.viewcomplaints.ViewComplaintsDefaultviewView viewComplaintsDefaultviewView = null;
	private static final String[][] VIEWCOMPLAINTSDEFAULTVIEWVIEW_PROPERTY_BINDINGS = new String[][] {
	};
	private transient caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.getactivenotification.GetActiveNotification getActiveNotification = null;
	public String getLogInUser() {
		return logInUser;
	}

	public void setLogInUser(String logInUser) {
		this.logInUser = logInUser;
	}

	public caf.war.Notifications2Citizens.viewcomplaints.ViewComplaintsDefaultviewView getViewComplaintsDefaultviewView()  {
		if (viewComplaintsDefaultviewView == null) {
		    viewComplaintsDefaultviewView = (caf.war.Notifications2Citizens.viewcomplaints.ViewComplaintsDefaultviewView)resolveExpression("#{ViewComplaintsDefaultviewView}");
		}
	
	    resolveDataBinding(VIEWCOMPLAINTSDEFAULTVIEWVIEW_PROPERTY_BINDINGS, viewComplaintsDefaultviewView, "viewComplaintsDefaultviewView", false, false);
		return viewComplaintsDefaultviewView;
	}

	public void setViewComplaintsDefaultviewView(caf.war.Notifications2Citizens.viewcomplaints.ViewComplaintsDefaultviewView viewComplaintsDefaultviewView)  {
		this.viewComplaintsDefaultviewView = viewComplaintsDefaultviewView;
	}

	public caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.getactivenotification.GetActiveNotification getGetActiveNotification()  {
		if (getActiveNotification == null) {
		    getActiveNotification = (caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.getactivenotification.GetActiveNotification)resolveExpression("#{GetActiveNotification}");
		}
	
	    resolveDataBinding(GETACTIVENOTIFICATION_PROPERTY_BINDINGS, getActiveNotification, "getActiveNotification", false, false);
		return getActiveNotification;
	}

	public void setGetActiveNotification(caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.getactivenotification.GetActiveNotification getActiveNotification)  {
		this.getActiveNotification = getActiveNotification;
	}
	boolean getAll=false;
	private static final String[][] GETACTIVENOTIFICATION_PROPERTY_BINDINGS = new String[][] {
		{"#{getActiveNotification.authCredentials.authenticationMethod}", "1"},
		{"#{getActiveNotification.authCredentials.requiresAuth}", "true"},
		{"#{getActiveNotification.endpointAddress}", "http://HSCSRV164.allegisgroup.com:5599/ws/TekathonxZeron.ws.getActiveNotification"},
		{"#{getActiveNotification.parameters.getActiveNotification.getActiveNotification.activeNotificationRequest.aadharID}", "#{ViewNotificationsDefaultviewView.logInUser}"},
		{"#{getActiveNotification.parameters.getActiveNotification.getActiveNotification.activeNotificationRequest.loginStatus}", "GUI"},
	};
	public boolean isGetAll() {
		return getAll;
	}

	public void setGetAll(boolean getAll) {
		this.getAll = getAll;
	}
}