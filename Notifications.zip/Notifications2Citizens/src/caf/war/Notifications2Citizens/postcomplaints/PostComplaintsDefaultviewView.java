/**
 * 
 */
package caf.war.Notifications2Citizens.postcomplaints;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.webmethods.caf.faces.annotations.ExpireWithPageFlow;
import com.webmethods.caf.faces.annotations.DTManagedBean;
import com.webmethods.caf.faces.annotations.BeanType;

/**
 * @author nmanchin
 *
 */

@ManagedBean(name = "PostComplaintsDefaultviewView")
@SessionScoped
@ExpireWithPageFlow
@DTManagedBean(displayName = "PostComplaints/default", beanType = BeanType.PAGE)
public class PostComplaintsDefaultviewView  extends   com.webmethods.caf.faces.bean.BasePageBean {

	/**
	 * Determines if a de-serialized file is compatible with this class.
	 *
	 * Maintainers must change this value if and only if the new version
	 * of this class is not compatible with old versions. See Sun docs
	 * for <a href=http://java.sun.com/j2se/1.5.0/docs/guide/serialization/spec/version.html> 
	 * details. </a>
	 */
	private static final long serialVersionUID = 1L;
	private static final String[][] INITIALIZE_PROPERTY_BINDINGS = new String[][] {
	};
	private transient caf.war.Notifications2Citizens.postcomplaints.PostComplaints postComplaints = null;
	private transient caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues4 getLookupValues4 = null;
	private transient caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues5 getLookupValues5 = null;
	private transient caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues6 getLookupValues6 = null;
	private transient caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerusercomplaint.RegisterUserComplaint registerUserComplaint = null;
	/**
	 * Initialize page
	 */
	public String initialize() {
		try {
		    resolveDataBinding(INITIALIZE_PROPERTY_BINDINGS, null, "initialize", true, false);
		    setLogInUser(getFacesContext().getExternalContext().getUserPrincipal().getName());
		} catch (Exception e) {
			error(e);
			log(e);
		}
		return null;	
	}
String logInUser=null;
	public String getLogInUser() {
	return logInUser;
}

public void setLogInUser(String logInUser) {
	this.logInUser = logInUser;
}

	public caf.war.Notifications2Citizens.postcomplaints.PostComplaints getPostComplaints()  {
		if (postComplaints == null) {
		    postComplaints = (caf.war.Notifications2Citizens.postcomplaints.PostComplaints)resolveExpression("#{PostComplaints}");
		}
		return postComplaints;
	}

	public caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues4 getGetLookupValues4()  {
		if (getLookupValues4 == null) {
		    getLookupValues4 = (caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues4)resolveExpression("#{GetLookupValues4}");
		}
	
	    resolveDataBinding(GETLOOKUPVALUES4_PROPERTY_BINDINGS, getLookupValues4, "getLookupValues4", false, false);
		return getLookupValues4;
	}

	public void setGetLookupValues4(caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues4 getLookupValues4)  {
		this.getLookupValues4 = getLookupValues4;
	}

	public caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues5 getGetLookupValues5()  {
		if (getLookupValues5 == null) {
		    getLookupValues5 = (caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues5)resolveExpression("#{GetLookupValues5}");
		}
	
	    resolveDataBinding(GETLOOKUPVALUES5_PROPERTY_BINDINGS, getLookupValues5, "getLookupValues5", false, false);
		return getLookupValues5;
	}

	public caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues6 getGetLookupValues6()  {
		if (getLookupValues6 == null) {
		    getLookupValues6 = (caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues6)resolveExpression("#{GetLookupValues6}");
		}
	
	    resolveDataBinding(GETLOOKUPVALUES6_PROPERTY_BINDINGS, getLookupValues6, "getLookupValues6", false, false);
		return getLookupValues6;
	}

	public void setGetLookupValues6(caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.lookupvalues.GetLookupValues6 getLookupValues6)  {
		this.getLookupValues6 = getLookupValues6;
	}

	public caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerusercomplaint.RegisterUserComplaint getRegisterUserComplaint()  {
		if (registerUserComplaint == null) {
		    registerUserComplaint = (caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerusercomplaint.RegisterUserComplaint)resolveExpression("#{RegisterUserComplaint}");
		}
	
	    resolveDataBinding(REGISTERUSERCOMPLAINT_PROPERTY_BINDINGS, registerUserComplaint, "registerUserComplaint", false, false);
		return registerUserComplaint;
	}

	public void setRegisterUserComplaint(caf.war.Notifications2Citizens.wsclient.tekathonxzeron.ws.registerusercomplaint.RegisterUserComplaint registerUserComplaint)  {
		this.registerUserComplaint = registerUserComplaint;
	}
	String postcode =null;
	String selectedCircle=null;
	String selectedDiv=null;
	private static final String[][] GETLOOKUPVALUES4_PROPERTY_BINDINGS = new String[][] {
		{"#{getLookupValues4.authCredentials.authenticationMethod}", "1"},
		{"#{getLookupValues4.authCredentials.requiresAuth}", "true"},
		{"#{getLookupValues4.endpointAddress}", "http://HSCSRV164.allegisgroup.com:5599/ws/TekathonxZeron.ws.lookupValues"},
		{"#{getLookupValues4.parameters.getLookupValues.getLookupValues.id}", "CIRCLE"},
		{"#{getLookupValues4.parameters.getLookupValues.getLookupValues.key}", "#{PostComplaintsDefaultviewView.postcode}"},
	};
	private static final String[][] GETLOOKUPVALUES5_PROPERTY_BINDINGS = new String[][] {
		{"#{getLookupValues5.authCredentials.authenticationMethod}", "1"},
		{"#{getLookupValues5.authCredentials.requiresAuth}", "true"},
		{"#{getLookupValues5.endpointAddress}", "http://HSCSRV164.allegisgroup.com:5599/ws/TekathonxZeron.ws.lookupValues"},
		{"#{getLookupValues5.parameters.getLookupValues.getLookupValues.id}", "DIVISION"},
		{"#{getLookupValues5.parameters.getLookupValues.getLookupValues.key}", "#{PostComplaintsDefaultviewView.selectedCircle}"},
	};
	private static final String[][] GETLOOKUPVALUES6_PROPERTY_BINDINGS = new String[][] {
		{"#{getLookupValues6.authCredentials.authenticationMethod}", "1"},
		{"#{getLookupValues6.authCredentials.requiresAuth}", "true"},
		{"#{getLookupValues6.endpointAddress}", "http://HSCSRV164.allegisgroup.com:5599/ws/TekathonxZeron.ws.lookupValues"},
		{"#{getLookupValues6.parameters.getLookupValues.getLookupValues.id}", "LANE"},
		{"#{getLookupValues6.parameters.getLookupValues.getLookupValues.key}", "#{PostComplaintsDefaultviewView.selectedDiv}"},
	};
	private static final String[][] REGISTERUSERCOMPLAINT_PROPERTY_BINDINGS = new String[][] {
		{"#{registerUserComplaint.authCredentials.authenticationMethod}", "1"},
		{"#{registerUserComplaint.authCredentials.requiresAuth}", "true"},
		{"#{registerUserComplaint.endpointAddress}", "http://HSCSRV164.allegisgroup.com:5599/ws/TekathonxZeron.ws.registerUserComplaint"},
		{"#{registerUserComplaint.parameters.registerUserComplaint.registerUserComplaint.registerUserComplaintRequest.complaintDetails.state}", "Telangana"},
		{"#{registerUserComplaint.parameters.registerUserComplaint.registerUserComplaint.registerUserComplaintRequest.complaintDetails.city}", "Hyderabad"},
		{"#{registerUserComplaint.parameters.registerUserComplaint.registerUserComplaint.registerUserComplaintRequest.complaintDetails.area}", "#{PostComplaintsDefaultviewView.postcode}"},
		{"#{registerUserComplaint.parameters.registerUserComplaint.registerUserComplaint.registerUserComplaintRequest.complaintDetails.circle}", "#{PostComplaintsDefaultviewView.selectedCircle}"},
		{"#{registerUserComplaint.parameters.registerUserComplaint.registerUserComplaint.registerUserComplaintRequest.complaintDetails.division}", "#{PostComplaintsDefaultviewView.selectedDiv}"},
		{"#{registerUserComplaint.parameters.registerUserComplaint.registerUserComplaint.registerUserComplaintRequest.complaintDetails.userAadharID}", "#{PostComplaintsDefaultviewView.logInUser}"},
	};
	public String getSelectedDiv() {
		return selectedDiv;
	}

	public void setSelectedDiv(String selectedDiv) {
		this.selectedDiv = selectedDiv;
	}

	public String getSelectedCircle() {
		return selectedCircle;
	}

	public void setSelectedCircle(String selectedCircle) {
		this.selectedCircle = selectedCircle;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	
}